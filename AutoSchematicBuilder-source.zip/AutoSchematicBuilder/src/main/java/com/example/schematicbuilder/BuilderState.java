package com.example.schematicbuilder;

import net.minecraft.util.math.BlockPos;
import java.nio.file.Path;

public final class BuilderState {
    private BuilderState() {}
    public static Path selectedFile;
    public static BlockPos anchor = BlockPos.ORIGIN;
    public static boolean hasAnchor = false;
    public static boolean previewEnabled = true;
    public static boolean positioningEnabled = false;
    public static boolean paused = false;
    public static String status = "Choose a schematic file to begin.";
    public static int rotation = 0;
    public static int offsetX = 0, offsetY = 0, offsetZ = 0;

    public static BlockPos effectiveAnchor() {
        return anchor.add(offsetX, offsetY, offsetZ);
    }
}
