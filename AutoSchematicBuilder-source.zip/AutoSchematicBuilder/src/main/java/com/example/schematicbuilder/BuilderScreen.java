package com.example.schematicbuilder;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class BuilderScreen extends Screen {
    private final List<Path> files = new ArrayList<>();
    private int selectedIndex = -1;
    private int listTop;
    private int listBottom;

    public BuilderScreen() { super(Text.literal("Auto Schematic Builder")); refreshFiles(); }

    private void refreshFiles() {
        files.clear();
        try (var stream = Files.list(AutoSchematicBuilderClient.schematicFolder)) {
            stream.filter(Files::isRegularFile)
                    .filter(p -> { String n = p.getFileName().toString().toLowerCase(); return n.endsWith(".schem") || n.endsWith(".schematic"); })
                    .sorted(Comparator.comparing(p -> p.getFileName().toString().toLowerCase()))
                    .forEach(files::add);
        } catch (Exception e) { BuilderState.status = "Folder read failed: " + e.getMessage(); }
        if (BuilderState.selectedFile != null) selectedIndex = files.indexOf(BuilderState.selectedFile);
    }

    @Override protected void init() {
        int left = this.width / 2 - 155;
        int right = this.width / 2 + 5;
        int y = 42;
        addDrawableChild(ButtonWidget.builder(Text.literal("Open Schematic Folder"), b -> openFolder()).dimensions(left, y, 150, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Refresh Schematics"), b -> refreshFiles()).dimensions(right, y, 150, 20).build());
        y += 25;
        addDrawableChild(ButtonWidget.builder(Text.literal("Load Schematic…"), b -> chooseFile()).dimensions(left, y, 150, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal(BuilderState.previewEnabled ? "Preview: ON" : "Preview: OFF"), b -> { BuilderState.previewEnabled = !BuilderState.previewEnabled; b.setMessage(Text.literal(BuilderState.previewEnabled ? "Preview: ON" : "Preview: OFF")); }).dimensions(right, y, 150, 20).build());
        y += 25;
        addDrawableChild(ButtonWidget.builder(Text.literal(BuilderState.positioningEnabled ? "Stick Positioning: ON" : "Enable Stick Positioning"), b -> { BuilderState.positioningEnabled = !BuilderState.positioningEnabled; b.setMessage(Text.literal(BuilderState.positioningEnabled ? "Stick Positioning: ON" : "Enable Stick Positioning")); BuilderState.status = BuilderState.positioningEnabled ? "Hold a stick and right-click a block to set the anchor." : "Stick positioning disabled."; }).dimensions(left, y, 150, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Reset Position"), b -> { BuilderState.offsetX = BuilderState.offsetY = BuilderState.offsetZ = 0; BuilderState.rotation = 0; BuilderState.status = "Offsets and rotation reset."; }).dimensions(right, y, 150, 20).build());
        y += 25;
        addDrawableChild(ButtonWidget.builder(Text.literal("X -"), b -> BuilderState.offsetX--).dimensions(left, y, 35, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("X +"), b -> BuilderState.offsetX++).dimensions(left + 38, y, 35, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Y -"), b -> BuilderState.offsetY--).dimensions(left + 76, y, 35, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Y +"), b -> BuilderState.offsetY++).dimensions(left + 114, y, 35, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Z -"), b -> BuilderState.offsetZ--).dimensions(right, y, 65, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Z +"), b -> BuilderState.offsetZ++).dimensions(right + 70, y, 65, 20).build());
        y += 25;
        addDrawableChild(ButtonWidget.builder(Text.literal("Rotate Left"), b -> { BuilderState.rotation = Math.floorMod(BuilderState.rotation - 90, 360); }).dimensions(left, y, 72, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Rotate Right"), b -> { BuilderState.rotation = Math.floorMod(BuilderState.rotation + 90, 360); }).dimensions(left + 77, y, 73, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Stop / Clear"), b -> { BuilderState.paused = false; BuilderState.status = "No automatic placement is running."; }).dimensions(right, y, 150, 20).build());
        listTop = y + 30; listBottom = this.height - 38;
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close()).dimensions(this.width / 2 - 40, this.height - 28, 80, 20).build());
    }

    private void chooseFile() {
        // Swing's native chooser runs off the render thread; return the result to Minecraft's client thread.
        Thread chooserThread = new Thread(() -> {
            try {
                JFileChooser chooser = new JFileChooser(AutoSchematicBuilderClient.schematicFolder.toFile());
                chooser.setDialogTitle("Select a Minecraft schematic");
                chooser.setFileFilter(new FileNameExtensionFilter("Minecraft schematics (*.schem, *.schematic)", "schem", "schematic"));
                int result = chooser.showOpenDialog(null);
                if (result == JFileChooser.APPROVE_OPTION) {
                    Path chosen = chooser.getSelectedFile().toPath();
                    MinecraftClient.getInstance().execute(() -> {
                        if (Files.isRegularFile(chosen)) {
                            BuilderState.selectedFile = chosen;
                            refreshFiles();
                            selectedIndex = files.indexOf(chosen);
                            BuilderState.status = "Selected file: " + chosen.getFileName() + ". Block parsing is not implemented in this starter build.";
                        }
                    });
                }
            } catch (Exception e) {
                MinecraftClient.getInstance().execute(() -> BuilderState.status = "File picker failed: " + e.getMessage());
            }
        }, "schematic-file-picker");
        chooserThread.setDaemon(true);
        chooserThread.start();
    }

    private void openFolder() {
        try { Files.createDirectories(AutoSchematicBuilderClient.schematicFolder); Util.getOperatingSystem().open(AutoSchematicBuilderClient.schematicFolder.toFile()); }
        catch (Exception e) { BuilderState.status = "Could not open folder: " + e.getMessage(); }
    }
    private void loadSelected() {
        if (selectedIndex < 0 || selectedIndex >= files.size()) { BuilderState.status = "Select a schematic from the list first."; return; }
        BuilderState.selectedFile = files.get(selectedIndex);
        BuilderState.status = "Selected file: " + BuilderState.selectedFile.getFileName() + ". File parsing and ghost-block rendering are not implemented in this starter build.";
    }

    @Override public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 12, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, "Folder: " + AutoSchematicBuilderClient.schematicFolder, width / 2, 27, 0xAAAAAA);
        super.render(context, mouseX, mouseY, delta);
        int y = listTop;
        context.drawTextWithShadow(textRenderer, "SCHEMATICS (click a row to select):", width / 2 - 155, y, 0xFFFFFF); y += 13;
        int visible = Math.max(0, (listBottom - y) / 13);
        for (int i = 0; i < Math.min(files.size(), visible); i++) {
            int index = i;
            boolean selected = i == selectedIndex;
            int color = selected ? 0xFF55FF55 : 0xFFE0E0E0;
            context.drawTextWithShadow(textRenderer, (selected ? "> " : "  ") + files.get(i).getFileName(), width / 2 - 155, y, color);
            y += 13;
        }
        if (files.isEmpty()) context.drawTextWithShadow(textRenderer, "No .schem or .schematic files found. Put files in the folder above.", width / 2 - 155, y, 0xFFAAAAAA);
        context.drawTextWithShadow(textRenderer, "Selected: " + (BuilderState.selectedFile == null ? "none" : BuilderState.selectedFile.getFileName()), width / 2 - 155, listBottom - 28, 0xFFFFFF);
        context.drawTextWithShadow(textRenderer, "Anchor: " + (BuilderState.hasAnchor ? BuilderState.effectiveAnchor().toShortString() : "not set") + " | Rotation: " + BuilderState.rotation + "°", width / 2 - 155, listBottom - 16, 0xFFFFFF);
        context.drawTextWithShadow(textRenderer, BuilderState.status, 8, height - 12, 0xFFFFD27F);
    }

    @Override public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && mouseX >= width / 2.0 - 155 && mouseX <= width / 2.0 + 155 && mouseY >= listTop + 13 && mouseY < listBottom - 30) {
            int row = (int) ((mouseY - (listTop + 13)) / 13);
            if (row >= 0 && row < files.size()) { selectedIndex = row; BuilderState.status = "Highlighted: " + files.get(row).getFileName() + ". Use Load Schematic or Load Selected."; return true; }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override public boolean shouldPause() { return false; }
}
