package com.example.schematicbuilder;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.world.World;
import net.minecraft.entity.player.PlayerEntity;
import org.lwjgl.glfw.GLFW;
import java.nio.file.Files;
import java.nio.file.Path;

public class AutoSchematicBuilderClient implements ClientModInitializer {
    public static Path schematicFolder;
    private static KeyBinding openMenuKey;

    @Override public void onInitializeClient() {
        schematicFolder = MinecraftClient.getInstance().runDirectory.toPath().resolve("config").resolve("schematic-builder");
        try { Files.createDirectories(schematicFolder); }
        catch (Exception e) { BuilderState.status = "Could not create schematic folder: " + e.getMessage(); }

        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.auto_schematic_builder.open_menu", GLFW.GLFW_KEY_RIGHT_CONTROL,
                KeyBinding.Category.MISC));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                if (client.currentScreen instanceof BuilderScreen) client.setScreen(null);
                else if (client.currentScreen == null) client.setScreen(new BuilderScreen());
            }
        });

        UseBlockCallback.EVENT.register((PlayerEntity player, World world, Hand hand, BlockHitResult hit) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (world.isClient && player == client.player && BuilderState.positioningEnabled
                    && player.getStackInHand(hand).isOf(Items.STICK)) {
                BuilderState.anchor = hit.getBlockPos().toImmutable();
                BuilderState.hasAnchor = true;
                BuilderState.status = "Anchor set to " + BuilderState.anchor.toShortString();
                player.sendMessage(Text.literal("[Schematic Builder] Anchor: " + BuilderState.anchor.toShortString()), true);
                return ActionResult.SUCCESS;
            }
            return ActionResult.PASS;
        });
    }
}
