# Auto Schematic Builder — Fabric 1.21.11 starter project

This is a source project, not a compiled JAR. It provides a client-only Fabric mod foundation with:

- Right Ctrl menu toggle
- Creates `config/schematic-builder` in the active Minecraft instance
- Opens the folder in the OS file manager
- Lists `.schem` and `.schematic` filenames and allows selecting a file
- Stick-based anchor selection while positioning mode is enabled
- GUI controls for offsets, 90-degree rotation, and preview toggle state

## Important current limitations

This first source build **does not yet parse schematic block data, render a ghost-block preview, or automatically place blocks**. Selecting a file only selects it; it does not claim to have loaded its block contents. Those features need a schematic-format parser and a renderer implemented against the exact 1.21.11 rendering APIs. This project intentionally does not simulate server-side placement or bypass server permissions.

## Build

Requires JDK 21 and Gradle 9.2.x (or compatible with the configured Loom version). From this folder run:

```bash
gradle build
```

The remapped mod JAR should appear under `build/libs/` if Gradle resolves dependencies and compilation succeeds. This environment did not have Gradle installed, so this source project has not been compiled or runtime-tested here.

## Install (after successful build)

Copy the remapped JAR from `build/libs/` into the `mods` folder for the Minecraft instance that runs Fabric 1.21.11. Make sure that instance has Fabric API installed too.

## Controls

- Right Ctrl: open/close menu
- In menu: Open Schematic Folder, Refresh Schematics, select a file row, Load Selected
- Enable Stick Positioning, then hold a stick and right-click a block to set the anchor
